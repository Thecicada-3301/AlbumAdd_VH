import sys
import urllib.parse
import xbmcgui
import xbmcplugin

# 1. Pegar a URL do plugin e o ID do handle fornecidos pelo Kodi
base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])

# 2. Sua lista de vídeos unificada de diferentes subdomínios do Netlify
VIDEOS = [
    {
        'title': 'Vídeo pri 1',
        'url': 'https://albump-3301.netlify.app/ft/vid-%20(2).mp4',
        'thumb': 'https://albump-3301.netlify.app/thumbs/thumb2.png'
    },
    {
        'title': 'Vídeo pri 2',
        'url': 'https://albump-3301.netlify.app/ft/vid-%20(3).mp4',
        'thumb': 'https://albump-3301.netlify.app/thumbs/thumb3.png'
    },
    {
        'title': 'Vídeo Al 1 (blow)',
        'url': 'https://album2-3301.netlify.app/Al/vid-%20(4).mp4',
        'thumb': 'https://via.placeholder.com/150'
    },
    {
        'title': 'Vídeo Al 2 (blow hd)',
        'url': 'https://album2-1-3301.netlify.app/Al/vid-%20(2).mp4',
        'thumb': 'https://via.placeholder.com/150'
    },
    {
        'title': 'Vídeo Al 3 (sentada)',
        'url': 'https://album2-3301.netlify.app/Al/vid-%20(7).mp4',
        'thumb': 'https://via.placeholder.com/150'
    },
    {
        'title': 'Vídeo Al 4 (sentada red)',
        'url': 'https://album2-1-3301.netlify.app/Al/vid-%20(1).mp4',
        'thumb': 'https://via.placeholder.com/150'
    },
    {
        'title': 'Vídeo Al 5 (botada red)',
        'url': 'https://album2-1-3301.netlify.app/Al/vid-%20(4).mp4',
        'thumb': 'https://via.placeholder.com/150'
    },
    {
        'title': 'Vídeo Al 6 (sentada red)',
        'url': 'https://album2-1-3301.netlify.app/Al/vid-%20(1).mp4',
        'thumb': 'https://via.placeholder.com/150'
    },
    {
        'title': 'Vídeo Tiv',
        'url': 'https://album3-3301.netlify.app/ft/vid-%20(2).mp4',
        'thumb': 'https://via.placeholder.com/150'
    }
]

def build_menu():
    # Loop para criar cada item na tela do Kodi
    for video in VIDEOS:
        # CORREÇÃO: Mudado de 'name=' para 'label='
        li = xbmcgui.ListItem(label=video['title'])
        
        # Define as miniaturas (Thumnails e Posters)
        li.setArt({'thumb': video['thumb'], 'poster': video['thumb']})
        
        # Informa ao Kodi que este item é um arquivo de vídeo final e executável
        li.setProperty('IsPlayable', 'true')
        
        # Adiciona o item à lista do Kodi
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=video['url'], listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)

# Executar a função se não houver parâmetros extras (abertura do add-on)
if not args:
    build_menu()